#pragma once
#include "header.h"

void Keyboard(unsigned char key, int x, int y);